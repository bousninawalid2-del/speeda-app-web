'use client';
import { useRouter } from 'next/navigation';
import { OnboardingScreen } from '@/screens/OnboardingScreen';
export default function Page() {
  const router = useRouter();
  return <div className="max-w-[430px] mx-auto relative min-h-screen bg-background overflow-x-hidden"><OnboardingScreen onComplete={() => router.push('/auth')} /></div>;
}
