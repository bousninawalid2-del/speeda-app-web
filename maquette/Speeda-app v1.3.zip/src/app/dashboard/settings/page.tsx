'use client';

import { useState, useEffect, useCallback } from 'react';
import { useRouter } from 'next/navigation';
import { SettingsScreen } from '@/screens/SettingsScreen';
import { resolveScreen } from '@/lib/navigation';
import { apiFetch } from '@/lib/api-client';

// Platform name (used in SettingsScreen) → Ayrshare platform ID
const PLATFORM_NAME_MAP: Record<string, string> = {
  Instagram:        'instagram',
  TikTok:           'tiktok',
  Snapchat:         'snapchat',
  Facebook:         'facebook',
  X:                'x',
  YouTube:          'youtube',
  'Google Business':'googlebusiness',
  LinkedIn:         'linkedin',
  Pinterest:        'pinterest',
  Threads:          'threads',
};

interface SocialResponse {
  accounts: { platform: string; connected: boolean }[];
}

export default function Page() {
  const router = useRouter();

  const [externalPlatforms, setExternalPlatforms] = useState<Record<string, boolean> | undefined>(undefined);

  const fetchPlatforms = useCallback(async () => {
    try {
      const data = await apiFetch<SocialResponse>('/social');
      // Map platform IDs → display names for SettingsScreen
      const map: Record<string, boolean> = {};
      for (const [name, id] of Object.entries(PLATFORM_NAME_MAP)) {
        const account = data.accounts.find(a => a.platform === id);
        map[name] = account?.connected ?? false;
      }
      setExternalPlatforms(map);
    } catch {
      setExternalPlatforms(undefined);
    }
  }, []);

  useEffect(() => { fetchPlatforms(); }, [fetchPlatforms]);

  const handleConnect = async (): Promise<string | null> => {
    try {
      const data = await apiFetch<{ url: string }>('/social/connect', { method: 'POST' });
      return data.url;
    } catch {
      return null;
    }
  };

  const handleDisconnect = async (platform: string) => {
    const id = PLATFORM_NAME_MAP[platform];
    if (!id) return;
    try {
      await apiFetch('/social/disconnect', {
        method: 'POST',
        body: JSON.stringify({ platform: id }),
      });
      setExternalPlatforms(prev => prev ? { ...prev, [platform]: false } : prev);
    } catch {
      fetchPlatforms();
    }
  };

  const handleSaveLanguage = async (lang: string) => {
    try {
      await apiFetch('/setup', {
        method: 'POST',
        body: JSON.stringify({ language_preference: lang }),
      });
    } catch {
      // Non-critical — language already applied locally via i18n
    }
  };

  return (
    <SettingsScreen
      onBack={() => router.push('/dashboard')}
      onNavigate={(s) => router.push(resolveScreen(s))}
      externalPlatforms={externalPlatforms}
      onSaveLanguage={handleSaveLanguage}
      onConnectPlatform={handleConnect}
      onDisconnectPlatform={handleDisconnect}
    />
  );
}
