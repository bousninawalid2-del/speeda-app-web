'use client';

import { Suspense } from 'react';
import { useRouter } from 'next/navigation';
import { useSearchParams } from 'next/navigation';
import { AIChatScreen } from '@/screens/AIChatScreen';
import { resolveScreen } from '@/lib/navigation';
import { apiFetch } from '@/lib/api-client';

function ChatContent() {
  const router = useRouter();
  const params = useSearchParams();
  const tab    = params.get('tab') as 'chat' | 'engagement' | null;
  const filter = params.get('filter') ?? undefined;
  const prefill = params.get('prefill');
  const initialInput = prefill === 'tokens' ? 'I need help choosing a token pack. What do you recommend?' : undefined;

  const handleSendMessage = async (
    message: string,
    history: Array<{ role: 'user' | 'assistant'; content: string }>
  ): Promise<string | null> => {
    try {
      const res = await apiFetch<{
        reply:      string;
        tokensUsed: number;
        history:    Array<{ role: string; content: string }>;
      }>('/ai', {
        method: 'POST',
        body: JSON.stringify({ message, history }),
      });
      return res.reply;
    } catch (err) {
      if (err instanceof Error && err.message.includes('402')) {
        return "You've run out of AI tokens. Visit the Tokens page to top up your balance!";
      }
      return null;
    }
  };

  return (
    <AIChatScreen
      initialTab={tab ?? 'chat'}
      initialInputValue={initialInput}
      initialEngagementFilter={filter}
      onNavigate={(s) => router.push(resolveScreen(s))}
      onSendMessage={handleSendMessage}
    />
  );
}

export default function Page() {
  return <Suspense><ChatContent /></Suspense>;
}
