'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { AuthScreen } from '@/screens/AuthScreen';
import { useAuth } from '@/contexts/AuthContext';
import { toast } from 'sonner';

export default function Page() {
  const router = useRouter();
  const { login, register, sendMagicLink } = useAuth();
  const [pendingUserId, setPendingUserId] = useState<string | null>(null);

  const handleLogin = async (email: string, password: string) => {
    try {
      await login(email, password);
      router.replace('/dashboard');
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Login failed');
      throw err; // let AuthScreen show its own error state
    }
  };

  const handleRegister = async (data: { name: string; email: string; password: string; phone?: string }) => {
    try {
      const { userId } = await register(data);
      setPendingUserId(userId);
      router.push(`/auth/verify?userId=${userId}&email=${encodeURIComponent(data.email)}`);
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Registration failed');
      throw err;
    }
  };

  const handleQuickLogin = async (email: string) => {
    try {
      await sendMagicLink(email);
      toast.success('Magic link sent! Check your email.');
    } catch (err: unknown) {
      toast.error(err instanceof Error ? err.message : 'Could not send magic link');
      throw err;
    }
  };

  return (
    <div className="max-w-[430px] mx-auto relative min-h-screen bg-background overflow-x-hidden">
      <AuthScreen
        onComplete={(mode) => {
          if (mode === 'signin') router.push('/dashboard');
          else router.push('/auth/verify');
        }}
        onForgotPassword={() => router.push('/auth/reset-password')}
        onLogin={handleLogin}
        onRegister={handleRegister}
        onQuickLogin={handleQuickLogin}
      />
    </div>
  );
}
