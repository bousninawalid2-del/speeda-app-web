import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db';
import { verifyRefreshToken, signAccessToken } from '@/lib/jwt';
import { errorResponse } from '@/lib/auth-guard';

const schema = z.object({ refreshToken: z.string() });

/** POST /api/auth/refresh — exchange a refresh token for a new access token */
export async function POST(request: NextRequest) {
  try {
    const body = await request.json();
    const parsed = schema.safeParse(body);
    if (!parsed.success) return errorResponse(parsed.error.issues[0].message);

    let payload;
    try {
      payload = verifyRefreshToken(parsed.data.refreshToken);
    } catch {
      return errorResponse('Invalid or expired refresh token', 401);
    }

    // Check DB record still exists (not revoked)
    const record = await prisma.refreshToken.findUnique({ where: { token: payload.jti } });
    if (!record || record.expiresAt < new Date()) {
      return errorResponse('Refresh token revoked or expired', 401);
    }

    const user = await prisma.user.findUnique({ where: { id: payload.sub } });
    if (!user) return errorResponse('User not found', 404);

    const accessToken = signAccessToken({
      sub: user.id,
      email: user.email,
      name: user.name ?? undefined,
    });

    return NextResponse.json({ accessToken });
  } catch (err) {
    console.error('[refresh]', err);
    return errorResponse('Internal server error', 500);
  }
}
