import { NextRequest, NextResponse } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db';
import { requireAuth, errorResponse } from '@/lib/auth-guard';
import { verifyRefreshToken } from '@/lib/jwt';

const schema = z.object({ refreshToken: z.string().optional() });

/** POST /api/auth/logout — revoke the provided refresh token */
export async function POST(request: NextRequest) {
  try {
    const auth = requireAuth(request);
    if (auth instanceof NextResponse) return auth;

    const body = await request.json().catch(() => ({}));
    const { refreshToken } = schema.parse(body);

    if (refreshToken) {
      try {
        const payload = verifyRefreshToken(refreshToken);
        await prisma.refreshToken.deleteMany({ where: { token: payload.jti } });
      } catch {
        // Token invalid — nothing to revoke
      }
    }

    return NextResponse.json({ message: 'Logged out successfully.' });
  } catch (err) {
    console.error('[logout]', err);
    return errorResponse('Internal server error', 500);
  }
}
