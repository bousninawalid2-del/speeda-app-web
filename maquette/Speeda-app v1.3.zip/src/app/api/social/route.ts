import { NextRequest } from 'next/server';
import { prisma } from '@/lib/db';
import { requireAuth, errorResponse } from '@/lib/auth-guard';
import { getConnectedPlatforms } from '@/lib/ayrshare';

// ─── GET /api/social — list connected social accounts ─────────────────────────

export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if (auth instanceof Response) return auth;
  const { user } = auth;

  // Load from DB
  const dbAccounts = await prisma.socialAccount.findMany({
    where: { userId: user.sub, connected: true },
  });

  // Try to enrich with live Ayrshare data
  const dbUser = await prisma.user.findUnique({
    where: { id: user.sub },
    select: { profileKey: true },
  });

  let liveData: Record<string, { username?: string; followers?: number }> = {};
  if (dbUser?.profileKey) {
    liveData = (await getConnectedPlatforms(dbUser.profileKey)) ?? {};
  }

  const accounts = dbAccounts.map(a => {
    const live = liveData[a.platform] ?? {};
    return {
      platform:   a.platform,
      username:   live.username  ?? a.username,
      followers:  live.followers ?? a.followers,
      connected:  a.connected,
      connectedAt: a.connectedAt,
    };
  });

  return Response.json({ accounts });
}
