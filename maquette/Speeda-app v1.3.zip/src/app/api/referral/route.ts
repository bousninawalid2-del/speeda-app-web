import { NextRequest, NextResponse } from 'next/server';
import { requireAuth } from '@/lib/auth-guard';
import { prisma } from '@/lib/db';

/**
 * GET /api/referral
 * Returns the current user's referral code, URL, and list of referred users.
 * The referral code is derived from the user's ID (stable, no extra DB field needed).
 */
export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if (auth instanceof NextResponse) return auth;
  const userId = auth.user.sub;

  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: { id: true, name: true, email: true },
  });
  if (!user) return NextResponse.json({ error: 'User not found' }, { status: 404 });

  // Use a stable referral code based on user ID (first 8 chars)
  const referralCode = userId.slice(0, 8).toLowerCase();
  const appUrl       = process.env.NEXT_PUBLIC_APP_URL ?? 'http://localhost:3000';
  const referralUrl  = `${appUrl}/invite/${referralCode}`;

  // For now we return empty friends list — extend this when referral tracking is added
  // Future: track via a Referral model with referrerId, refereeId, createdAt, status
  const friends: Array<{ name: string; status: 'signed_up' | 'pending'; tokens: number }> = [];

  return NextResponse.json({
    referralCode,
    referralUrl,
    totalInvited:  friends.length,
    totalSignedUp: friends.filter(f => f.status === 'signed_up').length,
    totalTokens:   friends.reduce((acc, f) => acc + f.tokens, 0),
    friends,
  });
}
