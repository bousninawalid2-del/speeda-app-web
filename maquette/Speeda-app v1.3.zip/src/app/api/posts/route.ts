import { NextRequest } from 'next/server';
import { z } from 'zod';
import { prisma } from '@/lib/db';
import { requireAuth, errorResponse } from '@/lib/auth-guard';
import { rateLimit } from '@/lib/rate-limit';

// ─── Validation ───────────────────────────────────────────────────────────────

const createSchema = z.object({
  platform:    z.string().min(1),
  caption:     z.string().min(1).max(4000),
  hashtags:    z.string().optional(),
  mediaUrls:   z.array(z.string()).optional(),
  scheduledAt: z.string().datetime().optional(),
  status:      z.enum(['Draft', 'Scheduled', 'Published']).optional(),
});

// ─── GET /api/posts ───────────────────────────────────────────────────────────

export async function GET(req: NextRequest) {
  const auth = requireAuth(req);
  if (auth instanceof Response) return auth;
  const { user } = auth;

  const { searchParams } = new URL(req.url);
  const platform = searchParams.get('platform') ?? undefined;
  const status   = searchParams.get('status')   ?? undefined;
  const page     = Math.max(1, parseInt(searchParams.get('page')  ?? '1'));
  const limit    = Math.min(100, parseInt(searchParams.get('limit') ?? '20'));
  const skip     = (page - 1) * limit;

  const where = {
    userId: user.sub,
    ...(platform ? { platform: { contains: platform } } : {}),
    ...(status   ? { status } : {}),
  };

  const [posts, total] = await prisma.$transaction([
    prisma.post.findMany({
      where,
      orderBy: { createdAt: 'desc' },
      skip,
      take: limit,
    }),
    prisma.post.count({ where }),
  ]);

  return Response.json({
    posts,
    pagination: { page, limit, total, pages: Math.ceil(total / limit) },
  });
}

// ─── POST /api/posts ──────────────────────────────────────────────────────────

export async function POST(req: NextRequest) {
  const auth = requireAuth(req);
  if (auth instanceof Response) return auth;
  const { user } = auth;

  // 30 post creations per user per minute
  if (!rateLimit(`posts:${user.sub}`, { limit: 30, windowMs: 60_000 })) {
    return errorResponse('Too many requests. Please wait a moment.', 429);
  }

  let body: unknown;
  try { body = await req.json(); } catch { return errorResponse('Invalid JSON', 400); }

  const parsed = createSchema.safeParse(body);
  if (!parsed.success) return errorResponse(parsed.error.issues[0].message, 400);

  const { platform, caption, hashtags, mediaUrls, scheduledAt, status } = parsed.data;

  const post = await prisma.post.create({
    data: {
      userId:      user.sub,
      platform,
      caption,
      hashtags:    hashtags ?? null,
      mediaUrls:   mediaUrls ? JSON.stringify(mediaUrls) : null,
      scheduledAt: scheduledAt ? new Date(scheduledAt) : null,
      status:      status ?? (scheduledAt ? 'Scheduled' : 'Draft'),
    },
  });

  return Response.json({ post }, { status: 201 });
}
