'use client';
import { useRouter } from 'next/navigation';
import { BusinessSetupScreen } from '@/screens/BusinessSetupScreen';
import { setupApi, SetupPayload } from '@/lib/api-client';
import { toast } from 'sonner';

export default function Page() {
  const router = useRouter();

  const handleSubmit = async (data: SetupPayload) => {
    await setupApi.save(data);
    toast.success('Setup complete! Welcome to Speeda 🚀');
  };

  return (
    <div className="max-w-[430px] mx-auto relative min-h-screen bg-background overflow-x-hidden">
      <BusinessSetupScreen
        onComplete={() => router.push('/dashboard')}
        onSubmit={handleSubmit}
        onUploadImage={setupApi.uploadImage}
        onDeleteImage={(id) => setupApi.deleteImage(id).then(() => undefined)}
      />
    </div>
  );
}
