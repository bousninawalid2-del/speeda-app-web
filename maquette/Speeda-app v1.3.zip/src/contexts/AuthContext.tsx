'use client';

import {
  createContext,
  useContext,
  useState,
  useEffect,
  useCallback,
  ReactNode,
} from 'react';
import {
  AuthUser,
  authApi,
  saveSession,
  clearSession,
  getStoredUser,
  getAccessToken,
  getRefreshToken,
} from '@/lib/api-client';

// ─── Types ────────────────────────────────────────────────────────────────────
interface RegisterData {
  name: string;
  email: string;
  password: string;
  phone?: string;
}

interface AuthContextValue {
  user: AuthUser | null;
  isLoading: boolean;
  isAuthenticated: boolean;

  /** Email + password register. Returns userId for verification. */
  register: (data: RegisterData) => Promise<{ userId: string }>;

  /** Email + password login. */
  login: (email: string, password: string) => Promise<void>;

  /** Quick login — sends a magic link to the email. */
  sendMagicLink: (email: string) => Promise<void>;

  /** Verify OTP code. Auto-logs in on success. */
  verifyEmail: (userId: string, code: string) => Promise<void>;

  /** Resend OTP. */
  resendVerification: (userId: string) => Promise<void>;

  /** Request a password reset link. */
  forgotPassword: (email: string) => Promise<void>;

  /** Complete password reset using link token. */
  resetPassword: (token: string, newPassword: string) => Promise<void>;

  /** Change password while logged in. */
  changePassword: (currentPassword: string, newPassword: string) => Promise<void>;

  /** Called by magic-link callback page after exchanging token for JWT pair. */
  loginWithTokens: (data: { accessToken: string; refreshToken: string; user: AuthUser }) => void;

  logout: () => Promise<void>;
}

// ─── Context ──────────────────────────────────────────────────────────────────
const AuthContext = createContext<AuthContextValue | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [user, setUser] = useState<AuthUser | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  // Rehydrate from localStorage on first render
  useEffect(() => {
    const stored = getStoredUser();
    const token = getAccessToken();
    if (stored && token) {
      setUser(stored);
      setAuthCookie(true);
    }
    setIsLoading(false);
  }, []);

  /** Write a simple presence cookie for the middleware (non-sensitive — just a flag). */
  const setAuthCookie = (set: boolean) => {
    if (set) {
      document.cookie = 'speeda_auth=1; path=/; max-age=604800; SameSite=Lax';
    } else {
      document.cookie = 'speeda_auth=; path=/; max-age=0';
    }
  };

  const loginWithTokens = useCallback(
    (data: { accessToken: string; refreshToken: string; user: AuthUser }) => {
      saveSession(data);
      setUser(data.user);
      setAuthCookie(true);
    },
    []
  );

  const register = useCallback(async (data: RegisterData) => {
    const res = await authApi.register(data);
    return { userId: res.userId };
  }, []);

  const login = useCallback(async (email: string, password: string) => {
    const data = await authApi.login({ email, password });
    loginWithTokens(data);
  }, [loginWithTokens]);

  const sendMagicLink = useCallback(async (email: string) => {
    await authApi.quickLogin(email);
  }, []);

  const verifyEmail = useCallback(async (userId: string, code: string) => {
    const data = await authApi.verify({ userId, code });
    loginWithTokens(data);
  }, [loginWithTokens]);

  const resendVerification = useCallback(async (userId: string) => {
    await authApi.resendVerify(userId);
  }, []);

  const forgotPassword = useCallback(async (email: string) => {
    await authApi.forgotPassword(email);
  }, []);

  const resetPassword = useCallback(async (token: string, newPassword: string) => {
    await authApi.resetPassword(token, newPassword);
  }, []);

  const changePassword = useCallback(async (currentPassword: string, newPassword: string) => {
    await authApi.changePassword(currentPassword, newPassword);
  }, []);

  const logout = useCallback(async () => {
    const rt = getRefreshToken();
    try { await authApi.logout(rt ?? undefined); } catch { /* ignore */ }
    clearSession();
    setAuthCookie(false);
    setUser(null);
  }, []);

  return (
    <AuthContext.Provider
      value={{
        user,
        isLoading,
        isAuthenticated: !!user,
        register,
        login,
        sendMagicLink,
        verifyEmail,
        resendVerification,
        forgotPassword,
        resetPassword,
        changePassword,
        loginWithTokens,
        logout,
      }}
    >
      {children}
    </AuthContext.Provider>
  );
}

export function useAuth(): AuthContextValue {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error('useAuth must be used inside <AuthProvider>');
  return ctx;
}
